﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

// Перечисление привилегий по работе с книгами
public enum LibraryPrivilege
{
    Standard,
    Premium
}

// Класс для представления книги
public class Book
{
    [NotNull]
    public string Title { get; set; }
    public bool IsOverdue { get; set; }
}

// Класс для представления посетителя библиотеки
public class Visitor
{
    [NotNull]
    public string LastName { get; set; }
    public LibraryPrivilege Privilege { get; set; }
    public List<Book> BorrowedBooks { get; set; } = new List<Book>();
}

// Главный класс программы
class Program
{
    static void Main()
    {
        // Создаем список посетителей библиотеки
        var visitors = new List<Visitor>
        {
            new Visitor { LastName = "Иванов", Privilege = LibraryPrivilege.Standard, BorrowedBooks = new List<Book> { new Book { Title = "Война и мир", IsOverdue = false } } },
            new Visitor { LastName = "Петров", Privilege = LibraryPrivilege.Premium, BorrowedBooks = new List<Book> { new Book { Title = "Преступление и наказание", IsOverdue = true } } }
        };

        // Выводим информацию о посетителях и их книгах
        foreach (var visitor in visitors)
        {
            Console.WriteLine($"Посетитель: {visitor.LastName}, Привилегия: {visitor.Privilege}");
            if (visitor.BorrowedBooks.Count > 0)
            {
                Console.WriteLine("На руках у посетителя:");
                foreach (var book in visitor.BorrowedBooks)
                {
                    Console.WriteLine($"- {book.Title}");
                    if (book.IsOverdue)
                    {
                        Console.WriteLine("Книга просрочена");
                    }
                }
            }
            else
            {
                Console.WriteLine("У посетителя нет книг на руках");
            }
            Console.WriteLine();
        }
    }
}
